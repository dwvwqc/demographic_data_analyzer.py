import pandas as pd

# Read the demographic data
df = pd.read_csv("adult.data.csv")

# 1. Number of people of each race
race_count = df["race"].value_counts()

# 2. Average age of men
average_age_men = round(df.loc[df["sex"] == "Male", "age"].mean(), 1)

# 3. Percentage of people with a Bachelor's degree
percentage_bachelors = round(
    (df["education"] == "Bachelors").mean() * 100, 1
)

# 4. Percentage of people with advanced education who earn more than 50K
advanced_education = ["Bachelors", "Masters", "Doctorate"]
higher_education = df[df["education"].isin(advanced_education)]
higher_education_rich = round(
    (higher_education["salary"] == ">50K").mean() * 100, 1
)

# 5. Percentage of people without advanced education who earn more than 50K
lower_education = df[~df["education"].isin(advanced_education)]
lower_education_rich = round(
    (lower_education["salary"] == ">50K").mean() * 100, 1
)

# 6. Minimum number of hours worked per week
min_work_hours = df["hours-per-week"].min()

# 7. Percentage of people working the minimum hours who earn more than 50K
minimum_hours_workers = df[df["hours-per-week"] == min_work_hours]
rich_percentage = round(
    (minimum_hours_workers["salary"] == ">50K").mean() * 100, 1
)

# 8. Country with the highest percentage of people earning more than 50K
rich_by_country = df[df["salary"] == ">50K"]["native-country"].value_counts()
people_by_country = df["native-country"].value_counts()
country_percentages = (rich_by_country / people_by_country) * 100

highest_earning_country = country_percentages.idxmax()
highest_earning_country_percentage = round(country_percentages.max(), 1)

# 9. Most popular occupation for people in India earning more than 50K
top_IN_occupation = (
    df[(df["native-country"] == "India") & (df["salary"] == ">50K")]["occupation"]
    .value_counts()
    .idxmax()
)
